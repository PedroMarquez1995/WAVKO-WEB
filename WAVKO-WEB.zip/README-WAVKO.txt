WAVKO — paquete web y backend Cloudflare

Este ZIP NO incluye la aplicación Android.

Contiene:
- website/: sitio web oficial WAVKO (portada violeta, fotografía, privacidad, términos y contacto).
- cloudflare/: código del Worker backend existente, conservado como fuente.

El workflow automático configurado en GitHub despliega únicamente website/ como Worker `wavko-web`. El backend de cloudflare/ no se despliega automáticamente con ese workflow para evitar modificar el servicio de comunicación sin confirmación.
