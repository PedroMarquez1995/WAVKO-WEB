ACTUALIZACIÓN WAVKO — BOTONES DE DESCARGA

- Botón «Descargar» añadido al menú superior, inmediatamente después de «Contacto».
- En la portada, «Conocer la privacidad» fue reemplazado por «Descargar».
- Ambos botones usan el enlace dinámico de GitHub Releases:
  https://github.com/PedroMarquez1995/voxgo-apk-walkietalkie/releases/latest/download/wavko.apk

IMPORTANTE:
Cada nueva Release debe incluir un archivo adjunto llamado exactamente wavko.apk.
El enlace /releases/latest/download/ resuelve a la última Release publicada, no a borradores ni prereleases.


ACTUALIZACIÓN — WORKER Y PORTADA CON VÍDEO

- El Worker del sitio web se llama ahora «wavko» (website/wrangler.jsonc).
  Al ejecutar «npx wrangler deploy» dentro de /website se publica en:
  https://wavko.pedroxhile.workers.dev/
  (El Worker anterior «wavko-web» queda en tu cuenta; puedes borrarlo desde el panel de Cloudflare.)
- La fotografía de la portada (wavko-hero.jpg) fue eliminada, junto con la carpeta website/assets.
- La portada usa un vídeo de fondo (autoplay, loop, muted, playsinline) alojado en R2, con capa violeta
  translúcida y un botón central translúcido de Silenciar/Activar sonido que aparece al tocar el vídeo
  (el vídeo inicia silenciado porque los navegadores bloquean el autoplay con sonido).
- La cabecera Content-Security-Policy permite media-src del dominio R2 y script inline.
- El Worker del servidor (cloudflare/, nombre «voxgo») NO se modificó para no cambiar su dirección.

- Menú móvil: «Descargar» alineado en la misma fila que el resto de opciones.

- Portada: se reproducen tres vídeos en orden (38980f43 → 9e12661b → 598c4519) y la lista se repite. Para cambiar/añadir vídeos edita HERO_VIDEOS en website/src/index.js.
- Portada: título, eslogan y botones alineados en la parte inferior del vídeo.
