ACTUALIZACIÓN WAVKO — BOTONES DE DESCARGA

- Botón «Descargar» añadido al menú superior, inmediatamente después de «Contacto».
- En la portada, «Conocer la privacidad» fue reemplazado por «Descargar».
- Ambos botones usan el enlace dinámico de GitHub Releases:
  https://github.com/PedroMarquez1995/voxgo-apk-walkietalkie/releases/latest/download/wavko.apk

IMPORTANTE:
Cada nueva Release debe incluir un archivo adjunto llamado exactamente wavko.apk.
El enlace /releases/latest/download/ resuelve a la última Release publicada, no a borradores ni prereleases.
