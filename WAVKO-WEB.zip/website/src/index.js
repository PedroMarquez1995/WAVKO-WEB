/*
 WAVKO — SITIO OFICIAL PARA CLOUDFLARE WORKERS
 Archivo: website/src/index.js

 INSTRUCCIONES:
 1. En Cloudflare, crea un Worker nuevo.
 2. Abre "Editar código" y pega TODO el contenido de este archivo.
 3. Guarda y despliega.
 4. Cloudflare asignará una dirección como:
    https://wavko.pedroxhile.workers.dev

 RUTAS:
 /                 Inicio
 /privacidad       Política de privacidad
 /terminos         Términos y condiciones
 /contacto         Contacto del desarrollador

 IMPORTANTE ANTES DE PUBLICAR:
 - La política y los términos se completaron tras revisar el ZIP facilitado.
 - Verifica que los dos correos publicados sean correctos y estén activos.
 - Si cambias el funcionamiento, los proveedores o el tratamiento de datos,
   actualiza también estas páginas antes de publicar.
*/

const BRAND = {
  name: "WAVKO",
  tagline: "Comunicación instantánea. Sin complicaciones.",
  email: "pedroluismarquezacevedo@gmail.com",
  developer: "Desarrollador de WAVKO"
};

// El archivo wavko.apk debe adjuntarse a cada nueva GitHub Release.
const DOWNLOAD_URL = "https://github.com/PedroMarquez1995/voxgo-apk-walkietalkie/releases/latest/download/wavko.apk";

// Vídeo de fondo de la portada (alojado en Cloudflare R2).
const HERO_VIDEO = "https://pub-186069c77bf94c4299150d4559069e6e.r2.dev/Videos/gemini_generated_video_38980f43.mp4";
const MEDIA_ORIGIN = "https://pub-186069c77bf94c4299150d4559069e6e.r2.dev";

const styles = `
:root{color-scheme:dark;--bg:#100827;--panel:#1b1040;--panel2:#241354;--purple:#7138d5;--lav:#c9a8ff;--text:#f8f5ff;--muted:#c5b8df;--line:rgba(211,185,255,.18)}
*{box-sizing:border-box}
html{scroll-behavior:smooth}
body{margin:0;background:radial-gradient(ellipse at 50% -15%,#6425b4 0%,#35116f 32%,#180b3d 67%,#100827 100%);color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,"Segoe UI",sans-serif;line-height:1.65;min-height:100vh}
a{color:#d8baff;text-decoration:none}
a:hover{color:#fff}
.shell{width:min(1080px,calc(100% - 40px));margin:auto}
header{position:sticky;top:0;z-index:5;background:rgba(17,8,40,.78);backdrop-filter:blur(18px);border-bottom:1px solid var(--line)}
.nav{min-height:76px;display:flex;align-items:center;justify-content:space-between;gap:20px}
.brand{display:flex;align-items:center;gap:12px;color:white;font-weight:800;letter-spacing:.04em;font-size:1.25rem}
.logo{width:42px;height:42px;border-radius:13px;display:grid;place-items:center;background:linear-gradient(145deg,#a77aff,#5120a5);box-shadow:0 8px 28px #08001480;border:1px solid #ffffff50;color:white;font-size:27px;font-weight:800}
nav{display:flex;align-items:center;gap:22px;flex-wrap:wrap}
nav a{font-size:.92rem;color:#e3d8f8}
nav a.download-nav{display:inline-flex;align-items:center;justify-content:center;padding:9px 17px;border-radius:999px;background:linear-gradient(120deg,#9861ed,#642bc0);color:#fff;font-weight:750;border:1px solid #ffffff45;box-shadow:0 7px 22px #08001455}
nav a.download-nav:hover{color:#fff;filter:brightness(1.12)}
.hero{text-align:center;position:relative;overflow:hidden;isolation:isolate;display:flex;align-items:center;justify-content:center;min-height:calc(100vh - 77px);min-height:calc(100svh - 77px);padding:72px 0;background:#180b3d;cursor:pointer;-webkit-tap-highlight-color:transparent}
.hero-video{position:absolute;inset:0;width:100%;height:100%;object-fit:cover;z-index:-2;pointer-events:none}
.hero-overlay{position:absolute;inset:0;z-index:-1;pointer-events:none;background:linear-gradient(180deg,rgba(24,11,61,.55) 0%,rgba(61,22,128,.50) 50%,rgba(16,8,39,.88) 100%)}
.hero .shell{position:relative;width:min(1080px,calc(100% - 40px))}
.hero-copy{position:relative}
.hero h1,.hero p{text-shadow:0 2px 24px rgba(8,0,20,.55)}
.hero-toggle{position:absolute;top:50%;left:50%;z-index:2;width:84px;height:84px;margin:-42px 0 0 -42px;padding:0;border-radius:50%;display:grid;place-items:center;color:#fff;cursor:pointer;background:rgba(255,255,255,.16);border:1px solid rgba(255,255,255,.38);-webkit-backdrop-filter:blur(14px) saturate(140%);backdrop-filter:blur(14px) saturate(140%);box-shadow:0 10px 40px rgba(8,0,20,.45);opacity:0;visibility:hidden;transform:scale(.88);transition:opacity .35s ease,transform .35s ease,visibility 0s linear .35s}
.hero-toggle.show{opacity:1;visibility:visible;transform:scale(1);transition:opacity .25s ease,transform .25s ease,visibility 0s}
.hero-toggle:hover{background:rgba(255,255,255,.26)}
.hero-toggle:focus-visible{outline:3px solid #d8baff;outline-offset:4px}
.hero-toggle svg{width:34px;height:34px;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round}
.hero-toggle .i-on{display:none}
.hero-toggle.is-on .i-on{display:block}
.hero-toggle.is-on .i-off{display:none}
.hero .actions{position:relative;z-index:3}
.rings{width:min(440px,78vw);aspect-ratio:1;margin:0 auto 34px;border-radius:50%;display:grid;place-items:center;position:relative;background:radial-gradient(circle,rgba(179,129,255,.15),transparent 65%)}
.rings:before,.rings:after{content:"";position:absolute;inset:5%;border:1px solid rgba(204,164,255,.28);border-radius:50%;box-shadow:0 0 45px rgba(147,76,255,.1)}
.rings:after{inset:17%;border-color:rgba(211,177,255,.42)}
.appicon{width:48%;aspect-ratio:1;border-radius:27%;display:grid;place-items:center;background:linear-gradient(145deg,#a981f4,#5826a8);border:1px solid #ffffff65;box-shadow:0 20px 65px #08001480;font-size:clamp(90px,17vw,160px);font-weight:750;line-height:1;color:#fff}
h1{font-size:clamp(3rem,9vw,5.6rem);line-height:1.05;letter-spacing:-.055em;margin:0 0 18px}
.hero p{font-size:clamp(1.1rem,3vw,1.55rem);color:#e3d5fb;margin:0 auto;max-width:650px}
.actions{display:flex;justify-content:center;gap:12px;flex-wrap:wrap;margin-top:30px}
.btn{display:inline-flex;align-items:center;justify-content:center;padding:12px 20px;border-radius:999px;background:linear-gradient(120deg,#9861ed,#642bc0);color:#fff;font-weight:700;border:1px solid #ffffff38;box-shadow:0 8px 24px #08001450}
.btn.secondary{background:#ffffff0d;box-shadow:none}
section{padding:34px 0 72px}
.section-title{text-align:center;font-size:clamp(1.8rem,4vw,2.5rem);letter-spacing:-.03em;margin:0 0 12px}
.lead{text-align:center;color:var(--muted);max-width:690px;margin:0 auto 30px}
.cards{display:grid;grid-template-columns:repeat(3,1fr);gap:16px}
.card,.content{background:linear-gradient(145deg,rgba(49,27,91,.88),rgba(27,15,62,.92));border:1px solid var(--line);border-radius:22px;padding:24px;box-shadow:0 18px 55px #07001430}
.card .symbol{font-size:1.6rem;margin-bottom:10px}
.card h3{margin:0 0 8px;font-size:1.12rem}
.card p{margin:0;color:var(--muted);font-size:.96rem}
.page{padding:58px 0 80px}
.eyebrow{color:#c7a5ff;text-transform:uppercase;letter-spacing:.15em;font-size:.78rem;font-weight:800}
.page h1{font-size:clamp(2.3rem,6vw,4rem);margin:8px 0 12px}
.content{max-width:850px;margin:28px auto 0}
.content h2{font-size:1.2rem;margin:28px 0 8px}
.content h2:first-child{margin-top:0}
.content p,.content li{color:#ded4ef}
.notice{border-left:3px solid #bd91ff;padding:12px 16px;background:#ffffff09;border-radius:0 12px 12px 0;color:#e6d9fa}
.contact-email{font-size:clamp(1rem,3vw,1.35rem);overflow-wrap:anywhere}
footer{border-top:1px solid var(--line);padding:26px 0 34px;color:#b9a9d5;font-size:.9rem}
.foot{display:flex;justify-content:space-between;gap:18px;flex-wrap:wrap}
.footlinks{display:flex;gap:18px;flex-wrap:wrap}
@media(max-width:720px){.nav{padding:12px 0;align-items:flex-start;flex-direction:column;gap:8px}nav{width:100%;flex-wrap:nowrap;justify-content:space-between;gap:6px}nav a{font-size:.8rem;white-space:nowrap}nav a.download-nav{padding:7px 11px;font-size:.8rem}.hero{padding:48px 0 56px}.hero-toggle{width:72px;height:72px;margin:-36px 0 0 -36px}.cards{grid-template-columns:1fr}.shell{width:min(100% - 28px,1080px)}.content{padding:20px}}
@media(max-width:345px){nav a,nav a.download-nav{font-size:.72rem}nav a.download-nav{padding:6px 9px}}
`;

function layout(title, description, body, active="") {
  const nav = [
    ["/","Inicio"],["/privacidad","Privacidad"],["/terminos","Términos"],["/contacto","Contacto"]
  ].map(([href,label])=>`<a href="${href}"${active===href?' aria-current="page"':''}>${label}</a>`).join("") + `<a class="download-nav" href="${DOWNLOAD_URL}">Descargar</a>`;
  return `<!doctype html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#241052">
<meta name="description" content="${description}">
<title>${title} | ${BRAND.name}</title>
<style>${styles}</style>
</head>
<body>
<header><div class="shell nav">
<a class="brand" href="/" aria-label="WAVKO, inicio"><span class="logo">w</span><span>WAVKO</span></a>
<nav aria-label="Navegación principal">${nav}</nav>
</div></header>
<main>${body}</main>
<footer><div class="shell foot">
<span>© ${new Date().getFullYear()} WAVKO. Todos los derechos reservados.</span>
<div class="footlinks"><a href="/privacidad">Privacidad</a><a href="/terminos">Términos</a><a href="/contacto">Contacto</a></div>
</div></footer>
</body></html>`;
}

function home() {
  const body = `
<section class="hero" id="hero">
<video class="hero-video" id="hero-video" src="${HERO_VIDEO}" autoplay loop muted playsinline preload="auto" aria-hidden="true" tabindex="-1"></video>
<div class="hero-overlay"></div>
<button type="button" class="hero-toggle" id="hero-toggle" aria-label="Activar sonido">
<svg class="i-off" viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z" fill="currentColor"/><path d="m22 9-6 6M16 9l6 6"/></svg>
<svg class="i-on" viewBox="0 0 24 24" aria-hidden="true"><path d="M11 5 6 9H3v6h3l5 4z" fill="currentColor"/><path d="M15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13"/></svg>
</button>
<div class="shell">
<div class="hero-copy"><h1>WAVKO</h1><p>${BRAND.tagline}</p></div>
<div class="actions"><a class="btn" href="/contacto">Contactar</a><a class="btn" href="${DOWNLOAD_URL}">Descargar</a></div>
</div></section>
<script>
(function(){
  var hero=document.getElementById("hero"),v=document.getElementById("hero-video"),b=document.getElementById("hero-toggle"),t;
  if(!hero||!v||!b)return;
  function sync(){
    b.classList.toggle("is-on",!v.muted);
    b.setAttribute("aria-label",v.muted?"Activar sonido":"Silenciar");
  }
  function reveal(){
    b.classList.add("show");
    clearTimeout(t);
    t=setTimeout(function(){b.classList.remove("show");},2500);
  }
  v.muted=true;
  var p=v.play();
  if(p&&p.catch)p.catch(function(){});
  v.addEventListener("volumechange",sync);
  sync();
  b.addEventListener("click",function(e){
    e.stopPropagation();
    v.muted=!v.muted;
    if(!v.muted)v.volume=1;
    if(v.paused){var r=v.play();if(r&&r.catch)r.catch(function(){});}
    sync();
    reveal();
  });
  hero.addEventListener("click",function(e){
    if(e.target.closest("a,button"))return;
    reveal();
  });
  document.addEventListener("visibilitychange",function(){if(!document.hidden&&v.paused)v.play().catch(function(){});});
})();
</script>
<section><div class="shell">
<h2 class="section-title">Tu voz, más cerca.</h2>
<p class="lead">WAVKO es una propuesta de comunicación por voz diseñada para hacer que conectarse sea sencillo.</p>
<div class="cards">
<article class="card"><div class="symbol">◉</div><h3>Comunicación directa</h3><p>Una experiencia centrada en la voz y en mantener la comunicación simple.</p></article>
<article class="card"><div class="symbol">⌁</div><h3>Experiencia intuitiva</h3><p>Una interfaz clara, moderna y pensada para que las funciones sean fáciles de encontrar.</p></article>
<article class="card"><div class="symbol">◇</div><h3>Diseño WAVKO</h3><p>Una identidad visual propia, con tonos violetas y una estética minimalista.</p></article>
</div></div></section>`;
  return layout("Comunicación instantánea", "Sitio oficial de WAVKO: comunicación instantánea, sin complicaciones.", body, "/");
}

function privacy() {
  const body = `<section class="page"><div class="shell">
<div class="eyebrow">Información legal</div><h1>Política de privacidad</h1>
<p class="lead">Última actualización: 21 de noviembre de 2026</p>
<div class="content">
<p>Esta política explica cómo WAVKO trata la información cuando utilizas su aplicación Android y sus servicios de comunicación. Se ha preparado revisando el proyecto Android y el Worker de Cloudflare facilitados para esta versión. Se aplica a las funciones descritas aquí; si una versión futura incorpora otras funciones o proveedores, esta política deberá actualizarse.</p>

<h2>1. Responsable y contacto</h2>
<p>El responsable del proyecto WAVKO es su desarrollador, <strong>Pedro Luis Márquez Acevedo</strong>. Para consultas sobre privacidad o datos personales puedes escribir a <a href="mailto:${BRAND.email}">${BRAND.email}</a>. También puedes utilizar <a href="mailto:Pedroxhile@gmail.com">Pedroxhile@gmail.com</a>.</p>
<p>WAVKO no publica en esta página un domicilio postal del responsable. Para ejercer tus derechos, utiliza los correos indicados. La legislación aplicable y los datos de contacto del responsable podrán precisarse si el servicio se constituye formalmente como empresa.</p>

<h2>2. Información que trata WAVKO</h2>
<ul>
<li><strong>Datos de cuenta y perfil:</strong> código de amigo, nombre visible, avatar o skin, listas de amigos, solicitudes, bloqueos y preferencias necesarias para prestar el servicio.</li>
<li><strong>Inicio de sesión con Google (opcional):</strong> cuando eliges esta opción, la aplicación recibe un identificador y datos básicos de perfil proporcionados por Google. El servidor verifica el token de Google y conserva el correo vinculado y un identificador derivado mediante hash para asociar el acceso a la cuenta.</li>
<li><strong>Audio:</strong> WAVKO utiliza el micrófono cuando mantienes pulsado el control para hablar en un canal o cuando grabas voluntariamente un mensaje de voz para un amigo. Los mensajes de voz directos pueden durar hasta 20 segundos.</li>
<li><strong>Mensajes y datos de comunicación:</strong> se procesan mensajes de texto y de voz que envías, además de los datos necesarios para entregarlos, como remitente, destinatario y fecha/hora.</li>
<li><strong>Notificaciones (opcionales):</strong> si Firebase Cloud Messaging está habilitado para la instalación, se registra el token de notificaciones del dispositivo para entregar avisos de invitaciones y mensajes.</li>
<li><strong>Datos técnicos y de seguridad:</strong> el servidor puede tratar datos de conexión y la dirección IP que Cloudflare incluye en las conexiones a canales para controles temporales de acceso y prevención de abusos. También se generan identificadores técnicos de sesión y registros internos necesarios para operar el servicio.</li>
</ul>

<h2>3. Permisos del dispositivo</h2>
<p>La versión Android revisada declara los permisos de Internet, grabación de audio, servicio en primer plano para micrófono, notificaciones, mantener el dispositivo activo, vibración e instalación de paquetes para el mecanismo de actualización de la aplicación. El micrófono se utiliza para las funciones de voz. Las notificaciones se utilizan para avisos cuando la función push está configurada.</p>
<p>En el manifiesto revisado no aparecen permisos para acceder a la ubicación ni a la agenda de contactos. La función de amigos utiliza códigos de amigo introducidos por los usuarios, no una lectura de la libreta de contactos.</p>

<h2>4. Cómo se utilizan los datos</h2>
<ul>
<li>Crear y mantener tu cuenta, perfil, amigos, solicitudes y bloqueos.</li>
<li>Conectar dispositivos a canales de comunicación por voz y administrar los turnos de transmisión.</li>
<li>Enviar mensajes directos de texto y de voz a amigos aceptados.</li>
<li>Entregar invitaciones y notificaciones cuando esa función está habilitada.</li>
<li>Proteger el servicio, limitar intentos fallidos y detectar usos abusivos.</li>
<li>Permitir el inicio de sesión, la recuperación y la eliminación de cuentas.</li>
</ul>

<h2>5. Audio, mensajes y cifrado</h2>
<p><strong>Audio en canales:</strong> el audio se transmite en tiempo real a través de la conexión con el servidor. Si el canal tiene una contraseña, la aplicación cifra el audio con AES-256-GCM y deriva la clave en el dispositivo; en ese caso, el servidor recibe el paquete cifrado y no dispone de la clave de cifrado. Si el canal no tiene contraseña, el código revisado no aplica ese cifrado de extremo a extremo al audio.</p>
<p><strong>Chat de canal:</strong> los mensajes se retransmiten a las personas conectadas al canal y no se guardan como historial permanente en el servidor. En canales con contraseña, el cliente aplica el mecanismo de cifrado previsto por el proyecto; en canales sin contraseña, no debe asumirse cifrado de extremo a extremo.</p>
<p><strong>Mensajes directos entre amigos:</strong> los mensajes de texto y de voz se mantienen temporalmente en el buzón del destinatario para que pueda recibirlos cuando vuelva a conectarse. El servidor aplica una caducidad de siete días al buzón y límites de cantidad. Los mensajes de voz directos se almacenan en el servidor hasta su entrega, eliminación o caducidad. En el código revisado no se implementa cifrado de extremo a extremo para estos mensajes directos; por ello, no los consideres comunicaciones privadas cifradas de extremo a extremo.</p>
<p>El historial de conversaciones que la aplicación conserva para mostrar en el dispositivo se guarda en el almacenamiento privado de la aplicación. La configuración Android revisada deshabilita la copia de seguridad automática de la aplicación.</p>

<h2>6. Dónde se procesan y quién presta servicios</h2>
<p>El servidor de WAVKO está diseñado para ejecutarse en <strong>Cloudflare Workers y Durable Objects</strong>, donde se procesan conexiones, cuentas, presencia, canales y buzones. La región concreta de procesamiento y los plazos de registros de infraestructura dependen de Cloudflare y de la configuración de la cuenta del operador.</p>
<p>El acceso con Google (si está habilitado en la compilación y configurado en el servidor) utiliza servicios de Google para validar los tokens de inicio de sesión. Las notificaciones push, si se activan, utilizan Firebase Cloud Messaging. La función de actualización puede consultar y descargar versiones publicadas en GitHub cuando se configura un repositorio para ello. Estos proveedores tratan la información conforme a sus propias condiciones y políticas de privacidad.</p>
<p>El proyecto puede funcionar sin configurar Firebase; en ese caso, las notificaciones push no se activan. WAVKO no incorpora en el código revisado SDK de publicidad ni analítica de terceros. La infraestructura del proveedor puede generar sus propios registros técnicos.</p>

<h2>7. Conservación</h2>
<ul>
<li>Los mensajes pendientes de texto y voz tienen una caducidad de siete días en el buzón del servidor; también se aplican límites de cantidad y la eliminación al recuperar o borrar mensajes.</li>
<li>Las invitaciones pendientes a canales caducan a los 15 minutos.</li>
<li>Los datos de cuenta y perfil se conservan mientras la cuenta siga activa, hasta que el usuario la elimine o sea necesario retirarlos por motivos operativos o legales.</li>
<li>Los datos guardados localmente en el dispositivo permanecen hasta que se eliminen desde la aplicación, se borren los datos de la aplicación o se desinstale. La eliminación de una cuenta en el servidor no debe entenderse como garantía de borrado de copias que el usuario haya exportado o conservado por su cuenta.</li>
<li>Los registros técnicos de Cloudflare, Google, Firebase o GitHub se rigen por las políticas y plazos de esos proveedores.</li>
</ul>

<h2>8. Seguridad</h2>
<p>El proyecto implementa controles como autenticación mediante tokens, almacenamiento de hashes para determinados secretos, hash PBKDF2 con salt para contraseñas, límites de intentos y cifrado AES-256-GCM para el audio de canales protegidos por contraseña. Estas medidas reducen ciertos riesgos, pero ningún sistema conectado a Internet puede garantizar seguridad absoluta. La protección de los canales sin contraseña y de los mensajes directos no equivale al cifrado de extremo a extremo.</p>

<h2>9. Tus opciones y derechos</h2>
<p>Puedes editar tu perfil, administrar amigos y bloqueos, desvincular métodos de acceso disponibles, retirar el permiso de micrófono o notificaciones desde los ajustes de Android y solicitar ayuda mediante el correo de contacto. La aplicación incluye una opción para eliminar la cuenta; al utilizarla, el servidor elimina los datos de cuenta asociados y las asociaciones de acceso correspondientes, según la implementación del proyecto.</p>
<p>También puedes solicitar acceso, corrección o eliminación de tus datos escribiendo a <a href="mailto:${BRAND.email}">${BRAND.email}</a>. Atenderemos la solicitud conforme a la legislación que resulte aplicable y podremos pedir información razonable para verificar que eres titular de la cuenta.</p>

<h2>10. Menores de edad</h2>
<p>WAVKO no está diseñada específicamente para menores de edad. Si la legislación de tu país exige autorización de un padre, madre o tutor para utilizar el servicio o tratar datos personales, esa autorización debe obtenerse antes de utilizarlo. Si crees que un menor ha proporcionado datos sin la autorización necesaria, contacta al desarrollador.</p>

<h2>11. Cambios de esta política</h2>
<p>Esta política puede actualizarse cuando cambien las funciones, los proveedores o las obligaciones aplicables. La fecha de actualización aparecerá al inicio de esta página. Te recomendamos revisarla periódicamente.</p>
</div></div></section>`;
  return layout("Política de privacidad", "Política de privacidad de WAVKO.", body, "/privacidad");
}

function terms() {
  const body = `<section class="page"><div class="shell">
<div class="eyebrow">Información legal</div><h1>Términos y condiciones</h1>
<p class="lead">Última actualización: 21 de noviembre de 2026</p>
<div class="content">
<p>Estos términos regulan el acceso y uso de WAVKO, una aplicación Android de comunicación por voz, canales, amigos y mensajería. Al instalar o utilizar la aplicación, aceptas estos términos. Si no estás de acuerdo, no debes utilizar el servicio.</p>

<h2>1. Descripción del servicio</h2>
<p>WAVKO ofrece funciones de comunicación tipo push-to-talk, canales de voz, perfiles, códigos de amigo, solicitudes de amistad, mensajes directos de texto y de voz, invitaciones y notificaciones opcionales. Algunas funciones dependen de que el servidor y los proveedores externos estén disponibles y correctamente configurados.</p>

<h2>2. Requisitos y cuenta</h2>
<p>Debes proporcionar información correcta cuando crees o configures una cuenta y mantener protegidos los medios de acceso. El proyecto puede permitir iniciar sesión con Google o vincular un correo y contraseña, según la configuración activa. Eres responsable de la actividad realizada desde tus credenciales y debes avisar al desarrollador si sospechas de un acceso no autorizado.</p>
<p>Si eres menor de edad, solo puedes utilizar WAVKO cuando tengas capacidad legal para aceptar estos términos o cuentes con la autorización de tu padre, madre o tutor cuando la ley lo exija.</p>

<h2>3. Uso aceptable</h2>
<p>Te comprometes a utilizar WAVKO de manera lícita y respetuosa. No debes:</p>
<ul>
<li>Utilizar la aplicación para amenazas, acoso, intimidación, fraude, suplantación o actividades ilegales.</li>
<li>Enviar contenido que vulnere derechos de terceros o que no tengas autorización para compartir.</li>
<li>Interferir con el funcionamiento del servicio, intentar acceder a cuentas o sistemas ajenos o eludir medidas de seguridad.</li>
<li>Distribuir malware, realizar spam o abusar de canales, invitaciones, mensajes o notificaciones.</li>
<li>Grabar, almacenar o divulgar comunicaciones de otras personas sin contar con la autorización o base legal necesaria.</li>
</ul>

<h2>4. Canales y comunicaciones</h2>
<p>Los usuarios son responsables del contenido que transmiten y comparten. El creador de un canal puede administrar participantes y expulsar usuarios de acuerdo con las herramientas disponibles. Los canales con contraseña utilizan el cifrado de audio previsto por la aplicación; los canales sin contraseña no ofrecen ese mismo cifrado de extremo a extremo. No compartas la contraseña de un canal con personas en quienes no confíes.</p>
<p>Los mensajes directos de texto y voz se guardan temporalmente en el buzón del destinatario para facilitar su entrega y pueden caducar después de siete días. Las invitaciones a canales caducan a los 15 minutos. No utilices WAVKO como único medio para comunicaciones de emergencia.</p>

<h2>5. Contenido y conducta de los usuarios</h2>
<p>Conservas los derechos que tengas sobre el contenido que envías. Al utilizar el servicio, autorizas técnicamente su transmisión y almacenamiento temporal en la medida necesaria para entregar tus comunicaciones y operar las funciones que solicitas. No debes enviar contenido ilegal, abusivo o que infrinja derechos de otras personas.</p>

<h2>6. Disponibilidad, cambios y suspensión</h2>
<p>WAVKO puede experimentar interrupciones, mantenimiento, errores o incompatibilidades. Las funciones, límites y requisitos técnicos pueden cambiar. El desarrollador puede limitar o suspender el acceso cuando sea razonablemente necesario para proteger el servicio, a sus usuarios, cumplir la ley o responder a un uso abusivo. Cuando sea posible, se procurará informar de cambios relevantes.</p>

<h2>7. Servicios de terceros</h2>
<p>Algunas funciones dependen de servicios de terceros, incluidos Cloudflare para la infraestructura del servidor, Google para el inicio de sesión y Firebase Cloud Messaging para notificaciones push opcionales. La descarga de actualizaciones puede depender de GitHub. El uso de esos servicios también está sujeto a sus propios términos y políticas.</p>

<h2>8. Propiedad intelectual</h2>
<p>La marca WAVKO, su identidad visual, diseño, software y demás elementos propios pertenecen a sus respectivos titulares. Estos términos no transfieren derechos de propiedad intelectual. No puedes copiar, modificar, distribuir o explotar elementos de WAVKO salvo autorización o cuando la ley lo permita.</p>

<h2>9. Privacidad</h2>
<p>El tratamiento de datos personales se describe en la <a href="/privacidad">Política de privacidad de WAVKO</a>, que forma parte de la información que debes revisar antes de utilizar la aplicación.</p>

<h2>10. Limitación de responsabilidad</h2>
<p>El servicio se proporciona según su disponibilidad técnica. En la medida permitida por la ley, el desarrollador no garantiza que el servicio esté libre de interrupciones, errores o pérdida de conectividad. Nada de estos términos excluye o limita responsabilidades o derechos que no puedan excluirse o limitarse conforme a la legislación aplicable. El usuario debe mantener medios alternativos para comunicaciones importantes o urgentes.</p>

<h2>11. Eliminación de cuenta</h2>
<p>Puedes utilizar la función de eliminación de cuenta disponible en la aplicación. La eliminación solicita al servidor borrar la información de cuenta asociada y desvincular los identificadores de acceso correspondientes. Los datos que ya estén guardados localmente en tu dispositivo, en copias realizadas por ti o en sistemas de terceros pueden requerir acciones separadas y estar sujetos a sus propios plazos de conservación.</p>

<h2>12. Cambios en estos términos</h2>
<p>Estos términos pueden actualizarse para reflejar cambios en WAVKO o en la legislación aplicable. La versión vigente estará publicada en esta página y mostrará su fecha de actualización. El uso continuado del servicio después de una actualización implica que has podido consultar la nueva versión, sin perjuicio de los derechos que te reconozca la ley.</p>

<h2>13. Legislación y derechos obligatorios</h2>
<p>Estos términos se interpretarán conforme a la legislación aplicable al responsable y al usuario. Si utilizas WAVKO desde Chile, se respetarán los derechos irrenunciables que correspondan conforme a la normativa chilena. Ninguna disposición pretende privarte de protecciones obligatorias que te reconozca la ley de tu país de residencia.</p>

<h2>14. Contacto</h2>
<p>El desarrollador de WAVKO es Pedro Luis Márquez Acevedo. Para consultas sobre estos términos, soporte o asuntos legales, escribe a <a href="mailto:${BRAND.email}">${BRAND.email}</a> o <a href="mailto:Pedroxhile@gmail.com">Pedroxhile@gmail.com</a>.</p>
</div></div></section>`;
  return layout("Términos y condiciones", "Términos y condiciones de uso de WAVKO.", body, "/terminos");
}

function contact() {
  const body = `<section class="page"><div class="shell">
<div class="eyebrow">Estamos para ayudarte</div><h1>Contacto</h1>
<p class="lead">¿Tienes una consulta, necesitas ayuda o quieres comunicarte con el desarrollador de WAVKO?</p>
<div class="content">
<h2>Contacto del desarrollador</h2>
<p>${BRAND.developer}</p>
<p class="contact-email"><a href="mailto:${BRAND.email}">${BRAND.email}</a></p>
<p>Para consultas relacionadas con privacidad, uso de la aplicación o soporte, puedes escribir a este correo.</p>
<p class="notice">Este correo es el canal de contacto publicado en el sitio. Asegúrate de que sea una dirección que revises regularmente.</p>
</div></div></section>`;
  return layout("Contacto", "Información de contacto del desarrollador de WAVKO.", body, "/contacto");
}

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const path = url.pathname.replace(/\/+$/, "") || "/";
    let html;
    if (path === "/") html = home();
    else if (path === "/privacidad") html = privacy();
    else if (path === "/terminos") html = terms();
    else if (path === "/contacto") html = contact();
    else {
      html = layout("Página no encontrada", "La página solicitada no existe.", `<section class="page"><div class="shell" style="text-align:center"><h1>404</h1><p>No encontramos esa página.</p><a class="btn" href="/">Volver al inicio</a></div></section>`);
    }
    return new Response(html, {
      status: path === "/" || ["/privacidad","/terminos","/contacto"].includes(path) ? 200 : 404,
      headers: {
        "content-type": "text/html; charset=UTF-8",
        "cache-control": "public, max-age=300",
        "x-content-type-options": "nosniff",
        "referrer-policy": "strict-origin-when-cross-origin",
        "content-security-policy": `default-src 'self'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; img-src 'self' data:; media-src 'self' ${MEDIA_ORIGIN}; base-uri 'self'; frame-ancestors 'none'`
      }
    });
  }
};
